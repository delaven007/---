"""
demo04_filter.py  频域滤波
"""
import numpy as np
import numpy.fft as nf
import matplotlib.pyplot as mp
import scipy.io.wavfile as wf
# 采样率，采样位移
sample_rate, sigs = \
	wf.read('../da_data/noised.wav')
print(sample_rate, sigs.shape)
sigs = sigs / (2**15)
times = np.arange(sigs.size) / sample_rate
# 绘图
mp.figure('Filter', facecolor='lightgray')
mp.subplot(221)
mp.title('Time Domain', fontsize=16)
mp.ylabel('Signal', fontsize=14)
mp.grid(linestyle=':')
mp.plot(times[:178], sigs[:178], 
	color='dodgerblue', label='Noised Signal')
mp.legend()

# fft变换后绘制频域图(频率/能量)
comp_ary = nf.fft(sigs)
pows = np.abs(comp_ary)
freqs = nf.fftfreq(
	sigs.size, times[1]-times[0])
mp.subplot(222)
mp.title('Frequency Domain', fontsize=16)
mp.ylabel('pow', fontsize=14)
mp.grid(linestyle=':')
mp.semilogy(freqs[freqs>0], pows[freqs>0],
	color='orangered', label='Freq')
mp.legend()

# 在频谱中去除噪声。
maxpow_freq = freqs[pows.argmax()]
noised_inds = np.where(freqs != maxpow_freq)
# 噪声的复数全抹为0
comp_ary[noised_inds] = 0
# 绘制降噪之后的频谱图像
pows = np.abs(comp_ary)
mp.subplot(224)
mp.ylabel('pow', fontsize=14)
mp.grid(linestyle=':')
mp.plot(freqs[freqs>0], pows[freqs>0],
	color='orangered', label='Freq')
mp.legend()

# 逆向傅里叶变换，输出时域函数图像
filter_sigs = nf.ifft(comp_ary)
mp.subplot(223)
mp.ylabel('Signal', fontsize=14)
mp.grid(linestyle=':')
mp.plot(times[:178], filter_sigs[:178], 
	color='dodgerblue', label='Filter Signal')
mp.legend()

# 保存文件
wf.write('../ml_data/filter.wav',
	sample_rate, 
	(filter_sigs * 2**15).astype(np.int16))

mp.tight_layout()
mp.show()
