"""
demo05_random.py 随机数  
"""
import numpy as np
# 命中率0.3，投10次，进几个？

n = np.random.binomial(10, 0.3, 100000)
for i in range(0, 11):
	p = (n==i).sum()/100000
	print(i, ':', p)
# 模拟客服接通概率
print(sum(np.random.binomial(3, 0.6, 200000) == 0) / 200000)

# 超几何分布
print(n)
n = np.random.hypergeometric(7, 3, 5, 200000)
for i in range(2, 6):
	p = (n==i).sum() / 200000
	print(i, ':', p)


