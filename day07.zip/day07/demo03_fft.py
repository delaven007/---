"""
demo0_fft.py  傅里叶变换拆方波
"""
import numpy as np
import matplotlib.pyplot as mp
import numpy.fft as nf

x = np.linspace(-2*np.pi, 2*np.pi, 1000)
y = np.zeros(x.size)
for i in range(1, 1000):
	y += 4*np.pi/(2*i-1) * np.sin((2*i-1)*x)

# 画图
mp.figure('FFT', facecolor='lightgray')
mp.subplot(121)
mp.title('Time Domain', fontsize=18)
mp.grid(linestyle=':')
mp.plot(x, y, label=r'$y$')
# 针对方波y，做fft
comp_ary = nf.fft(y)
y2 = nf.ifft(comp_ary).real
mp.plot(x, y2, color='orangered', 
	linewidth=5, alpha=0.5, label=r'$y$')
# 绘制频域图像(频率/能量) 
mp.subplot(122)
freqs = nf.fftfreq(y.size, x[1]-x[0])
pows = np.abs(comp_ary) # 复数的模
mp.title('Frequency Domain', fontsize=18)
mp.grid(linestyle=':')
mp.plot(freqs[freqs>0], pows[freqs>0], 
	color='orangered', label='frequency')
mp.legend()
mp.show()






