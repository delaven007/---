"""
demo09_ndimage.py 简单图像处理
"""
import numpy as np
import scipy.misc as sm
import scipy.ndimage as sn
import matplotlib.pyplot as mp

img = sm.imread('../da_data/lily.jpg', True)
print(img.shape)

mp.figure('Ndimage', facecolor='lightgray')
mp.subplot(221)
mp.axis('off')
mp.imshow(img, cmap='gray')
# 高斯模糊
img2 = sn.median_filter(img, 20)
mp.subplot(222)
mp.axis('off')
mp.imshow(img2, cmap='gray')
# 旋转
img3 = sn.rotate(img, 45)
mp.subplot(223)
mp.axis('off')
mp.imshow(img3, cmap='gray')
# 边缘识别
img4 = sn.prewitt(img)
mp.subplot(224)
mp.axis('off')
mp.imshow(img4, cmap='gray')

mp.tight_layout()
mp.show()










