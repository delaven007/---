"""
demo06_sort.py   排序
"""
import numpy as np

names = np.array(['Apple', 'Mi', 'Oppo', 
				  'Vivo', 'Huawei'])
price = [8888, 2999, 3999, 3999, 4999]
volume = np.array([50, 100, 90, 88, 110])
# 联合间接排序
sorted_inds = np.lexsort((-volume, price))
print(names[sorted_inds])


a = np.array([1,2,4,6])
b = np.array([3,5])
indics = np.searchsorted(a, b)
print(indics)
d = np.insert(a, indics, b)
print(d)
