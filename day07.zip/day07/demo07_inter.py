"""
demo07_inter.py  插值
"""
import numpy as np
import scipy.interpolate as si
import matplotlib.pyplot as mp

# 原始数据 11组数据
min_x = -50
max_x = 50
dis_x = np.linspace(min_x, max_x, 15)
dis_y = np.sinc(dis_x)
mp.scatter(dis_x, dis_y, color='dodgerblue',
	s=70)
# 绘制线性插值器函数
linear = si.interp1d(dis_x, dis_y)
x = np.linspace(min_x, max_x, 1000)
y = linear(x)
mp.plot(x, y)
# 三次样条插值器
cubic = si.interp1d(
	dis_x, dis_y, kind='cubic')
x = np.linspace(min_x, max_x, 1000)
y = cubic(x)
mp.plot(x, y)

mp.show()
