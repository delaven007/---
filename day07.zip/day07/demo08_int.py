"""
demo08_int.py  积分
"""
import numpy as np
import matplotlib.pyplot as mp
import matplotlib.patches as mc
import scipy.integrate as si

def f(x):
	return 2 * x**2 + 3*x + 4

a, b = -5, 5
x = np.linspace(a, b, 1000)
y = f(x)
mp.figure('Integral', facecolor='lightgray')
mp.title('Integral', fontsize=16)
mp.grid(linestyle=':')
mp.plot(x, y, c='orangered', zorder=3,
	linewidth=6, label='f(x)')
# 计算f(x)在[-5, 5]区间的定积分
n = 50
x = np.linspace(a, b, n+1)
y = f(x)
area = 0
for i in range(n):
	area+=(y[i] + y[i+1]) * (x[1]-x[0]) / 2
print(area)
for i in range(n):
    mp.gca().add_patch(mc.Polygon([
        [x[i], 0], [x[i], y[i]],
        [x[i + 1], y[i + 1]], [x[i + 1], 0]],
        fc='deepskyblue', ec='dodgerblue',
        alpha=0.5))
    
# 基于scipy求积分
r = si.quad(f, -5, 5)
print(r)

mp.legend()
mp.show()

