"""
demo02_lily.py  图片特征提取
"""
import numpy as np
import scipy.misc as sm
import matplotlib.pyplot as mp

# 读取图片数据, True:提取亮度矩阵
img = sm.imread('../da_data/lily.jpg', True)
print(img, img.shape)
# 提取特征值：
eigvals, eigvecs = np.linalg.eig(np.mat(img))
# 逆向推导原矩阵：
eigvals[50:] = 0
img2 = eigvecs * np.diag(eigvals) * \
		eigvecs.I
# 绘制图片
mp.figure('Lily', facecolor='lightgray')
mp.subplot(221)
mp.imshow(img, cmap='gray')
mp.xticks([])
mp.yticks([])
mp.subplot(222)
mp.imshow(img2.real, cmap='gray')
mp.xticks([])
mp.yticks([])

# 奇异值分解
U, sv, V = np.linalg.svd(np.mat(img))
sv[30:] = 0 
img3 = U * np.diag(sv) * V
mp.subplot(224)
mp.imshow(img3.real, cmap='gray')
mp.xticks([])
mp.yticks([])



mp.tight_layout()
mp.show()




