"""
demo05_poly.py  多项式拟合
"""
import numpy as np
import matplotlib.pyplot as mp
import datetime as dt
import matplotlib.dates as md

def dmy2ymd(dmy):
	''' 把日月年 转 年月日 '''
	dmy = str(dmy, encoding='utf-8')
	t = dt.datetime.strptime(dmy, '%d-%m-%Y')
	s = t.date().strftime('%Y-%m-%d')
	return s

dates, bhp_closing_prices = \
	np.loadtxt('../da_data/bhp.csv',
		delimiter=',', usecols=(1,6),
		unpack=True, dtype='M8[D],f8',
		converters={1:dmy2ymd})

vale_closing_prices = \
	np.loadtxt('../da_data/vale.csv',
		delimiter=',', usecols=(6,),
		unpack=True)

# 绘制收盘价的折线图
mp.figure('Polyfit', facecolor='lightgray')
mp.title('Polyfit', fontsize=18)
mp.xlabel('Date', fontsize=14)
mp.ylabel('Price', fontsize=14)
mp.grid(linestyle=':')
# 设置刻度定位器  
# 每周一一个主刻度， 一天一个次刻度
ax = mp.gca()
ma_loc = md.WeekdayLocator(byweekday=md.MO)
ax.xaxis.set_major_locator(ma_loc)
ax.xaxis.set_major_formatter(
	md.DateFormatter('%Y-%m-%d'))
ax.xaxis.set_minor_locator(md.DayLocator())
# 修改dates的dtype为md.datetime.datetime
dates = dates.astype(md.datetime.datetime)

# 计算差价
diff_prices = bhp_closing_prices - \
				vale_closing_prices
mp.plot(dates, diff_prices, 
	color='dodgerblue', label='diff prices')
# 多项式拟合
days = dates.astype('M8[D]').astype('i4')
P = np.polyfit(days, diff_prices, 4)
y = np.polyval(P, days)
mp.plot(dates, y, color='orangered',
	linewidth=2, label='Polyfit line')

mp.legend()
mp.gcf().autofmt_xdate()
mp.show()









