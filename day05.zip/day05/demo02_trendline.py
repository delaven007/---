"""
demo02_trendline.py  趋势线
"""
import numpy as np
import matplotlib.pyplot as mp
import datetime as dt
import matplotlib.dates as md

def dmy2ymd(dmy):
	''' 把日月年 转 年月日 '''
	dmy = str(dmy, encoding='utf-8')
	t = dt.datetime.strptime(dmy, '%d-%m-%Y')
	s = t.date().strftime('%Y-%m-%d')
	return s

dates, opening_prices, highest_prices, \
	lowest_prices, closing_prices = \
	np.loadtxt('../da_data/aapl.csv',
		delimiter=',', usecols=(1,3,4,5,6),
		unpack=True, dtype='M8[D],f8,f8,f8,f8',
		converters={1:dmy2ymd})

# 绘制收盘价的折线图
mp.figure('AAPL', facecolor='lightgray')
mp.title('AAPL', fontsize=18)
mp.xlabel('Date', fontsize=14)
mp.ylabel('Price', fontsize=14)
mp.grid(linestyle=':')
# 设置刻度定位器  
# 每周一一个主刻度， 一天一个次刻度
ax = mp.gca()
ma_loc = md.WeekdayLocator(byweekday=md.MO)
ax.xaxis.set_major_locator(ma_loc)
ax.xaxis.set_major_formatter(
	md.DateFormatter('%Y-%m-%d'))
ax.xaxis.set_minor_locator(md.DayLocator())
# 修改dates的dtype为md.datetime.datetime
dates = dates.astype(md.datetime.datetime)
mp.plot(dates, closing_prices, 
	color='dodgerblue', linewidth=2, 
	linestyle='--', alpha=0.2, 
	label='AAPL Closing Price')

# 整理每天的趋势价格，绘制拟合得到的趋势线  
trend_points = (highest_prices + \
	lowest_prices + closing_prices) / 3
mp.scatter(dates, trend_points, s=70,
	color='orangered',label='trend points')
# 整理A与B
days = dates.astype('M8[D]').astype('i4')
# 让x与一组1进行列合并
A = np.column_stack((days, np.ones(days.size)))
B = trend_points
x = np.linalg.lstsq(A, B)[0]
# 将日期带入线性模型，得到每天的趋势价格
trend_prices = x[0]*days + x[1]
mp.plot(dates, trend_prices, color='red',
	label='Trend Line')

mp.legend()
mp.gcf().autofmt_xdate()
mp.show()








