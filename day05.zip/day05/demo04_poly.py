"""
demo04_poly.py
"""
import numpy as np
import matplotlib.pyplot as mp

P = [4, 3, -1000, 1]
x = np.linspace(-20, 20, 1000)
y = np.polyval(P, x) # 把x带入P函数，得到y'

# 求导
Q = np.polyder(P)
# 求导函数的根，切线斜率为0时x的值
xs = np.roots(Q)
ys = np.polyval(P, xs)
mp.plot(x, y)
mp.scatter(xs, ys, s=80, marker='o',
	color='red')
mp.show()

