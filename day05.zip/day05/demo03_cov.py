"""
demo03_cov.py  协方差
"""
import numpy as np
import matplotlib.pyplot as mp
import datetime as dt
import matplotlib.dates as md

def dmy2ymd(dmy):
	''' 把日月年 转 年月日 '''
	dmy = str(dmy, encoding='utf-8')
	t = dt.datetime.strptime(dmy, '%d-%m-%Y')
	s = t.date().strftime('%Y-%m-%d')
	return s

dates, bhp_closing_prices = \
	np.loadtxt('../da_data/bhp.csv',
		delimiter=',', usecols=(1,6),
		unpack=True, dtype='M8[D],f8',
		converters={1:dmy2ymd})

vale_closing_prices = \
	np.loadtxt('../da_data/vale.csv',
		delimiter=',', usecols=(6,),
		unpack=True)

# 绘制收盘价的折线图
mp.figure('COV', facecolor='lightgray')
mp.title('COV', fontsize=18)
mp.xlabel('Date', fontsize=14)
mp.ylabel('Price', fontsize=14)
mp.grid(linestyle=':')
# 设置刻度定位器  
# 每周一一个主刻度， 一天一个次刻度
ax = mp.gca()
ma_loc = md.WeekdayLocator(byweekday=md.MO)
ax.xaxis.set_major_locator(ma_loc)
ax.xaxis.set_major_formatter(
	md.DateFormatter('%Y-%m-%d'))
ax.xaxis.set_minor_locator(md.DayLocator())
# 修改dates的dtype为md.datetime.datetime
dates = dates.astype(md.datetime.datetime)
mp.plot(dates, bhp_closing_prices, 
	color='dodgerblue', linewidth=2, 
	linestyle='-', alpha=0.8, 
	label='BHP Closing Price')
mp.plot(dates, vale_closing_prices, 
	color='orangered', linewidth=2, 
	linestyle='-', alpha=0.8, 
	label='VALE Closing Price')

# 计算两只股股票收盘价的协方差
mean_bhp = np.mean(bhp_closing_prices)
mean_vale = np.mean(vale_closing_prices)
dev_bhp = bhp_closing_prices - mean_bhp
dev_vale = vale_closing_prices - mean_vale
cov = (dev_bhp * dev_vale).mean()
print('cov:', cov)
k = cov / (np.std(bhp_closing_prices) * \
		np.std(vale_closing_prices))
print('k:', k)

# 使用相关矩阵得到两组数据的相关系数
k = np.corrcoef(bhp_closing_prices, 
		vale_closing_prices)
print(k)

# 求两组数据的协方差
covm = np.cov(bhp_closing_prices, 
	vale_closing_prices)
print(covm)

mp.legend()
mp.gcf().autofmt_xdate()
mp.show()








