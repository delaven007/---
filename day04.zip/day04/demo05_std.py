"""
demo05_std.py  标准差
"""
import numpy as np
import matplotlib.pyplot as mp
import datetime as dt
import matplotlib.dates as md

def dmy2ymd(dmy):
	''' 把日月年 转 年月日 '''
	dmy = str(dmy, encoding='utf-8')
	t = dt.datetime.strptime(dmy, '%d-%m-%Y')
	s = t.date().strftime('%Y-%m-%d')
	return s

dates, opening_prices, highest_prices, \
	lowest_prices, closing_prices,\
	volumes = np.loadtxt('../da_data/aapl.csv',
		delimiter=',', usecols=(1,3,4,5,6,7),
		unpack=True, 
		dtype='M8[D],f8,f8,f8,f8,f8',
		converters={1:dmy2ymd})

std_c = np.std(closing_prices)  # 总体
print(std_c)
std_o = np.std(opening_prices)
print(std_o)
std_c2 = np.std(closing_prices, ddof=1) # 样本
print(std_c2)

# 手动实现
m = np.mean(closing_prices)
d = closing_prices - m
v = np.mean(d**2)
s = np.sqrt(v)
print(s)  # 总体标准差
v2 = (d**2).sum() / (d.size-1)
s2 = np.sqrt(v2)
print(s2) # 样本标准差






