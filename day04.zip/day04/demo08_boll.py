"""
demo08_boll.py  布林带
"""
import numpy as np
import matplotlib.pyplot as mp
import datetime as dt
import matplotlib.dates as md

def dmy2ymd(dmy):
	''' 把日月年 转 年月日 '''
	dmy = str(dmy, encoding='utf-8')
	t = dt.datetime.strptime(dmy, '%d-%m-%Y')
	s = t.date().strftime('%Y-%m-%d')
	return s

dates, opening_prices, highest_prices, \
	lowest_prices, closing_prices = \
	np.loadtxt('../da_data/aapl.csv',
		delimiter=',', usecols=(1,3,4,5,6),
		unpack=True, dtype='M8[D],f8,f8,f8,f8',
		converters={1:dmy2ymd})

# 绘制收盘价的折线图
mp.figure('AAPL', facecolor='lightgray')
mp.title('AAPL', fontsize=18)
mp.xlabel('Date', fontsize=14)
mp.ylabel('Price', fontsize=14)
mp.grid(linestyle=':')
# 设置刻度定位器  
# 每周一一个主刻度， 一天一个次刻度
ax = mp.gca()
ma_loc = md.WeekdayLocator(byweekday=md.MO)
ax.xaxis.set_major_locator(ma_loc)
ax.xaxis.set_major_formatter(
	md.DateFormatter('%Y-%m-%d'))
ax.xaxis.set_minor_locator(md.DayLocator())
# 修改dates的dtype为md.datetime.datetime
dates = dates.astype(md.datetime.datetime)
mp.plot(dates, closing_prices, 
	color='dodgerblue', linewidth=2, 
	linestyle='--', alpha=0.8, 
	label='AAPL Closing Price')

# 布林带
# 5日加权平均线
kernel = np.exp(np.linspace(-1, 0, 5))
kernel /= kernel.sum()
ma53 = np.convolve(
	closing_prices, kernel[::-1], 'valid')
mp.plot(dates[4:], ma53, color='orangered',
	label='MA-53')
# 最近5日标准差数组
stds = np.zeros(ma53.size)
for i in range(stds.size):
	stds[i] = closing_prices[i:i+5].std()
# 计算上轨和下轨
upper = ma53 + 2*stds
lower = ma53 - 2*stds
mp.plot(dates[4:], upper, color='orangered',
	label='Upper')
mp.plot(dates[4:], lower, color='orangered',
	label='Lower')
mp.fill_between(dates[4:], upper, lower,
	upper>lower, color='orangered', 
	alpha=0.1)


mp.legend()
mp.gcf().autofmt_xdate()
mp.show()








