"""
demo03_max.py  最值
"""
import numpy as np
import matplotlib.pyplot as mp
import datetime as dt
import matplotlib.dates as md

def dmy2ymd(dmy):
	''' 把日月年 转 年月日 '''
	dmy = str(dmy, encoding='utf-8')
	t = dt.datetime.strptime(dmy, '%d-%m-%Y')
	s = t.date().strftime('%Y-%m-%d')
	return s

dates, opening_prices, highest_prices, \
	lowest_prices, closing_prices,\
	volumes = np.loadtxt('../da_data/aapl.csv',
		delimiter=',', usecols=(1,3,4,5,6,7),
		unpack=True, 
		dtype='M8[D],f8,f8,f8,f8,f8',
		converters={1:dmy2ymd})

# 30天的最大震荡幅度
max_price = np.max(highest_prices)
min_price = np.min(lowest_prices)
print(min_price, '~', max_price)

# 哪一天是最高价， 哪一天是最低价
max_ind = np.argmax(highest_prices)
min_ind = np.argmin(lowest_prices)
print('min:', dates[min_ind])
print('max:', dates[max_ind])

# 
a = np.arange(1, 10).reshape(3, 3)
b = np.arange(1, 10)[::-1].reshape(3, 3)
print(np.maximum(a, b))
print(np.minimum(a, b))


















