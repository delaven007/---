"""
demo04_median.py  中位数
"""
import numpy as np
import matplotlib.pyplot as mp
import datetime as dt
import matplotlib.dates as md

def dmy2ymd(dmy):
	''' 把日月年 转 年月日 '''
	dmy = str(dmy, encoding='utf-8')
	t = dt.datetime.strptime(dmy, '%d-%m-%Y')
	s = t.date().strftime('%Y-%m-%d')
	return s

dates, opening_prices, highest_prices, \
	lowest_prices, closing_prices,\
	volumes = np.loadtxt('../da_data/aapl.csv',
		delimiter=',', usecols=(1,3,4,5,6,7),
		unpack=True, 
		dtype='M8[D],f8,f8,f8,f8,f8',
		converters={1:dmy2ymd})

# 绘制收盘价的折线图
mp.figure('AAPL', facecolor='lightgray')
mp.title('AAPL', fontsize=18)
mp.xlabel('Date', fontsize=14)
mp.ylabel('Price', fontsize=14)
mp.grid(linestyle=':')
# 设置刻度定位器  
# 每周一一个主刻度， 一天一个次刻度
ax = mp.gca()
ma_loc = md.WeekdayLocator(byweekday=md.MO)
ax.xaxis.set_major_locator(ma_loc)
ax.xaxis.set_major_formatter(
	md.DateFormatter('%Y-%m-%d'))
ax.xaxis.set_minor_locator(md.DayLocator())
# 修改dates的dtype为md.datetime.datetime
dates = dates.astype(md.datetime.datetime)
mp.plot(dates, closing_prices, 
	color='dodgerblue', linewidth=2, 
	linestyle='--', alpha=0.8, 
	label='AAPL Closing Price')

# 计算收盘价的均值
mean = np.mean(closing_prices)
mean = closing_prices.mean()
mp.hlines(mean, dates[0], dates[-1], 
	color='orangered', label='mean')

# VWAP 成交量加权平均值
vwap = np.average(
	closing_prices, weights=volumes)
mp.hlines(vwap, dates[0], dates[-1], 
	color='blue', label='VWAP')

# TWAP 时间加权平均价格
w = np.linspace(1, 4, 30)
twap = np.average(
	closing_prices, weights=w)
mp.hlines(twap, dates[0], dates[-1], 
	color='green', label='TWAP')

# 中位数
median = np.median(closing_prices)
sorted_prices = np.msort(closing_prices)
size = sorted_prices.size
median = (sorted_prices[int(size/2)] + 
	sorted_prices[int((size-1)/2)]) / 2
print(median)
mp.hlines(median, dates[0], dates[-1], 
	color='gold', label='median')

mp.legend()
mp.gcf().autofmt_xdate()
mp.show()








