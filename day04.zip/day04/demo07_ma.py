"""
demo07_ma.py  移动平均线
"""
import numpy as np
import matplotlib.pyplot as mp
import datetime as dt
import matplotlib.dates as md

def dmy2ymd(dmy):
	''' 把日月年 转 年月日 '''
	dmy = str(dmy, encoding='utf-8')
	t = dt.datetime.strptime(dmy, '%d-%m-%Y')
	s = t.date().strftime('%Y-%m-%d')
	return s

dates, opening_prices, highest_prices, \
	lowest_prices, closing_prices = \
	np.loadtxt('../da_data/aapl.csv',
		delimiter=',', usecols=(1,3,4,5,6),
		unpack=True, dtype='M8[D],f8,f8,f8,f8',
		converters={1:dmy2ymd})

# 绘制收盘价的折线图
mp.figure('AAPL', facecolor='lightgray')
mp.title('AAPL', fontsize=18)
mp.xlabel('Date', fontsize=14)
mp.ylabel('Price', fontsize=14)
mp.grid(linestyle=':')
# 设置刻度定位器  
# 每周一一个主刻度， 一天一个次刻度
ax = mp.gca()
ma_loc = md.WeekdayLocator(byweekday=md.MO)
ax.xaxis.set_major_locator(ma_loc)
ax.xaxis.set_major_formatter(
	md.DateFormatter('%Y-%m-%d'))
ax.xaxis.set_minor_locator(md.DayLocator())
# 修改dates的dtype为md.datetime.datetime
dates = dates.astype(md.datetime.datetime)
mp.plot(dates, closing_prices, 
	color='dodgerblue', linewidth=2, 
	linestyle='--', alpha=0.6, 
	label='AAPL Closing Price')

# 绘制5日移动平均线
ma5 = np.zeros(closing_prices.size-4)
for i in range(ma5.size):
	ma5[i] = np.mean(closing_prices[i:i+5])
mp.plot(dates[4:], ma5, color='orangered',
	label='MA-5')

# 基于卷积绘制5日均线
kernel = np.ones(5) / 5
ma52 = np.convolve(
		closing_prices, kernel, 'valid')
mp.plot(dates[4:], ma52, color='orangered',
	label='MA-52', linewidth=7, alpha=0.3)

# 绘制10日移动平均线
kernel = np.ones(10) / 10
ma10 = np.convolve(
		closing_prices, kernel, 'valid')
mp.plot(dates[9:], ma10, color='green',
	label='MA-10')

# 基于卷积实现5日加权平均线
# 寻找一组卷积核
kernel = np.exp(np.linspace(-1, 0, 5))
# 卷积核中所有元素之和=1
kernel /= kernel.sum()
ma53 = np.convolve(
	closing_prices, kernel[::-1], 'valid')
mp.plot(dates[4:], ma53, color='violet',
	label='MA-53')

mp.legend()
mp.gcf().autofmt_xdate()
mp.show()

'''
kernel = [5,4,3,2,1]

a b c d e f g h i j k l ...
1 2 3 4 5
1 2 3 2 1
1 1 2 2 3 
...

'''





