"""
demo06_wday.py  
统计周一、二...五的收盘价均值
"""
import numpy as np
import matplotlib.pyplot as mp
import datetime as dt
import matplotlib.dates as md

def dmy2wday(dmy):
	''' 把日月年 转 周n '''
	dmy = str(dmy, encoding='utf-8')
	t = dt.datetime.strptime(dmy, '%d-%m-%Y')
	wday = t.date().weekday()
	return wday

wdays, closing_prices = \
	np.loadtxt('../da_data/aapl.csv',
		delimiter=',', usecols=(1,6),
		unpack=True, 
		dtype='f8,f8',
		converters={1:dmy2wday})

ave_prices = np.zeros(5)
for i in range(ave_prices.size):
	ave_prices[i] = np.mean(
		closing_prices[wdays==i])
print(ave_prices)

# 数组的轴向汇总
prices = closing_prices.reshape(6, 5)
print(prices)


def func(ary):
	# 数组处理函数
	return np.mean(ary), np.std(ary)

r = np.apply_along_axis(func, 0, prices)
print(np.round(r, 2))
