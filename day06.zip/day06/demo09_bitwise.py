"""
demo09_bitwise.py  位运算通用函数
"""
import numpy as np

a = np.array([1, -2, 2, -2, -6])
b = np.array([3, 3, 3, 3, -6])
print(np.bitwise_xor(a, b))
print(a ^ b)
c = a ^ b
r = np.where(c<0)[0]  # 返回符合条件的索引
print(r)

a = np.arange(1000000)
print(a[a&(a-1)==0])
