"""
demo02_piecewise.py  数组处理函数
"""
import numpy as np
import matplotlib.pyplot as mp

ary = np.array([60, 40, 10, 3, 80, 70])
r = np.piecewise(ary, 
	[np.all([ary<=100, ary>=60], axis=0), 
	ary<60], [1, 0])
print(r)
