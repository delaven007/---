"""
demo06_clip.py  裁剪与压缩
"""
import numpy as np

ary = np.arange(10)
print(ary)
print(ary.clip(min=3, max=7))
print(ary.compress(ary%2==0))
