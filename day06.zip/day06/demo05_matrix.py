"""
demo05_matrix.py   矩阵
"""
import numpy as np
# 创建matrix对象 (1)
ary = np.arange(1, 10).reshape(3, 3)
print(ary, type(ary))
ary2 = np.matrix(ary, copy=True)
print(ary2, type(ary2))
ary[0,0] = 999
print(ary2, type(ary2))
# 创建matrix对象 (2)
m3 = np.mat(ary)
print(m3)
# 创建matrix对象 (3)
m4 = np.mat('1 2 3; 4 5 6')
print(m4, type(m4))

# 矩阵的乘法
m = np.mat('1 2 6; 3 5 7; 4 8 9')
print(m * m)
a = np.array(m)
print(a * a)
print(a.dot(a))

# 逆矩阵
print(m.I)
print(np.linalg.inv(m))
print(m * m.I)

# 针对非方阵
m = m[:2, :]
print(m)
print(m.I)
print(m * m.I)
# print(np.linalg.inv(m))

# 解方程：
A = np.mat('3 3.2; 3.5 3.6')
B = np.mat('118.4; 135.2')
x = np.linalg.lstsq(A, B)[0]
print(x)
x = A.I * B
print(x)

print(np.mat('4234 2342; 2342 234') ** 0)







