from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(UserInfo)
admin.site.register(Hold)
admin.site.register(Fund)
admin.site.register(Bank)