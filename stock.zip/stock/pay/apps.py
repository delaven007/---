from django.apps import AppConfig


class PayConfig(AppConfig):
    name = 'pay'
