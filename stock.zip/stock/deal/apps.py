from django.apps import AppConfig


class DealConfig(AppConfig):
    name = 'deal'
