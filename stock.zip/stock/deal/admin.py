from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(SelfStock)
admin.site.register(BOSStock)
admin.site.register(DealStock)