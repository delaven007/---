import numpy as np
import matplotlib.pyplot as mp
import matplotlib.animation as ma

# 随机生成100个泡泡，并且初始化所有属性
n = 100
balls = np.zeros(n, dtype=[
	('position', 'f8', 2), 
	('size', 'f8', 1), 
	('growth', 'f8', 1), 
	('color', 'f8', 4)])
balls['position']=np.random.uniform(0,1,(n,2))
balls['size']=np.random.uniform(40,80,n)
balls['growth']=np.random.uniform(10,20,n)
balls['color']=np.random.uniform(0,1,(n,4))
# 绘制图像 
mp.figure('Animation', facecolor='lightgray')
mp.title('Animation', fontsize=14)
mp.xticks([])
mp.yticks([])
sc = mp.scatter(balls['position'][:,0],
	balls['position'][:,1], s=balls['size'],
	color=balls['color'])

# 定义并执行动画
def update(number):
	# 更新每个泡泡的size
	balls['size'] += balls['growth']
	# 选择一个点，重新初始化属性
	index = number % 100
	balls[index]['size'] = \
		np.random.uniform(40, 80, 1)
	balls[index]['position'] = \
		np.random.uniform(0, 1, (1, 2))

	sc.set_sizes(balls['size'])
	sc.set_offsets(balls['position'])

anim = ma.FuncAnimation(
	mp.gcf(), update, interval=30)

mp.show()