"""
demo02_bar.py  柱状图
"""
import numpy as np
import matplotlib.pyplot as mp

apples = np.array(
	[10,94,45,23,90,65,29,30,46,50,24,65])
oranges = np.array(
	[90,56,10,96,51,9,60,51,96,5,92,79])

mp.figure('Bar Chart', facecolor='lightgray')
mp.title('Bar Chart', fontsize=16)
mp.xlabel('Date', fontsize=14)
mp.ylabel('Volume', fontsize=14)
mp.grid(linestyle=':', axis='y')
x = np.arange(apples.size)

mp.bar(x-0.2, apples, 0.4, color='dodgerblue',
	label='Apple', align='center')
mp.bar(x+0.2, oranges, 0.4, color='orangered',
	label='Orange', align='center')

mp.xticks(x, ['Jan', 'Feb', 'Mar', 'Apr',
	'May', 'Jun', 'Jul', 'Aug', 'Sep',
	'Oct', 'Nov', 'Dec'])

mp.legend()
mp.show()
