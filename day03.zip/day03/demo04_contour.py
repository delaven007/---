"""
demo04_contour.py 等高线图
"""
import numpy as np
import matplotlib.pyplot as mp

n = 500
x, y = np.meshgrid(np.linspace(-3, 3, n), 
				   np.linspace(-3, 3, n))
z = (1 - x/2 + x**5 + y**3) * \
	np.exp(-x**2 - y**2)
# 绘制等高线
mp.figure('Contour', facecolor='lightgray')
mp.title('Contour', fontsize=16)
cntr=mp.contour(x, y, z, 8, colors='black',
	linewidths=0.75)
# 为等高线添加标签
mp.clabel(cntr, fmt='%.1f', 
	inline_spacing=5, fontsize=8)
# 填充等高线
mp.contourf(x, y, z, 8, cmap='jet')
mp.show()

