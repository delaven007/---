"""
demo09_3dwireframe.py 3D线框图
"""
import numpy as np
import matplotlib.pyplot as mp
from mpl_toolkits.mplot3d import axes3d
n = 500
x, y = np.meshgrid(np.linspace(-3, 3, n), 
				   np.linspace(-3, 3, n))
z = (1 - x/2 + x**5 + y**3) * \
	np.exp(-x**2 - y**2)
# 绘制3D曲面图
mp.figure('3D WireFrame', facecolor='lightgray')
ax3d = mp.gca(projection='3d')
ax3d.plot_wireframe(x, y, z, cstride=10,
	rstride=10, linewidth=0.5, 
	color='orangered')
mp.tight_layout()
mp.show()





